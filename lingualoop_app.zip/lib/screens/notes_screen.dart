
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

class NotesScreen extends StatefulWidget {
  final String audioFileName;

  NotesScreen({required this.audioFileName});

  @override
  _NotesScreenState createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadNote();
  }

  Future<void> _loadNote() async {
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/${widget.audioFileName}.txt';
    final file = File(path);
    if (await file.exists()) {
      _controller.text = await file.readAsString();
    }
  }

  Future<void> _saveNote() async {
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/${widget.audioFileName}.txt';
    final file = File(path);
    await file.writeAsString(_controller.text);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Nota guardada')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notas'),
        actions: [
          IconButton(icon: Icon(Icons.save), onPressed: _saveNote),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: TextField(
          controller: _controller,
          maxLines: null,
          decoration: InputDecoration.collapsed(hintText: "Escribe tus notas aquí..."),
        ),
      ),
    );
  }
}
